<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Custom Template - SilkPanel CMS</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-purple-50 to-blue-50">
    <div class="min-h-screen flex items-center justify-center p-4">
        <div class="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8">
            <div class="text-center">
                <h1 class="text-5xl font-bold text-gray-900 mb-4">
                    🎨 Custom Template Active!
                </h1>
                <p class="text-xl text-gray-600 mb-8">
                    This is a custom welcome page from your template.
                </p>
                <div class="bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-lg p-6 mb-6">
                    <p class="text-lg font-medium">
                        ✨ Template System Working Perfectly ✨
                    </p>
                </div>
                <div class="space-y-4 text-left bg-gray-50 rounded-lg p-6">
                    <h2 class="text-lg font-semibold text-gray-900">Features:</h2>
                    <ul class="space-y-2 text-gray-700">
                        <li class="flex items-center">
                            <span class="mr-2">✅</span> Custom views override defaults
                        </li>
                        <li class="flex items-center">
                            <span class="mr-2">✅</span> Fallback to default views
                        </li>
                        <li class="flex items-center">
                            <span class="mr-2">✅</span> Easy upload and activation
                        </li>
                        <li class="flex items-center">
                            <span class="mr-2">✅</span> Multiple templates support
                        </li>
                    </ul>
                </div>
                <div class="mt-8">
                    <a href="/templates" class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-gray-900 hover:bg-gray-800">
                        Manage Templates →
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
